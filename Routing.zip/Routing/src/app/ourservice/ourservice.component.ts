import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ourservice',
  templateUrl: './ourservice.component.html',
  styleUrls: ['./ourservice.component.css']
})
export class OurserviceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
